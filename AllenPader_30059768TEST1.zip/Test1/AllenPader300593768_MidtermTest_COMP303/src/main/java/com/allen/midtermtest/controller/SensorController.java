package com.allen.midtermtest.controller;

import com.allen.midtermtest.model.Sensor;
import com.allen.midtermtest.repository.SensorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
public class SensorController {

    @Autowired
    private SensorRepository sensorRepository;

    // Display all sensors
    @GetMapping("/sensors")
    public String showAllSensors(Model model) {
        List<Sensor> sensors = sensorRepository.findAll();
        model.addAttribute("sensors", sensors);
        return "sensors"; // Will map to sensors.html in templates
    }

    // Add a new sensor
    @PostMapping("/addSensor")
    public String addNewSensor(@RequestParam String sensorName,
                               @RequestParam String sensorType,
                               @RequestParam Integer sensorPin,
                               @RequestParam String sensorLocation,
                               @RequestParam String sensorStatus) {

        Sensor sensor = new Sensor();
        sensor.setSensorName(sensorName);
        sensor.setSensorType(sensorType);
        sensor.setSensorPin(sensorPin);
        sensor.setSensorLocation(sensorLocation);
        sensor.setSensorStatus(sensorStatus);

        sensorRepository.save(sensor);
        return "redirect:/sensors";  // Redirect to the list of sensors after adding
    }

    // Count how many sensors are registered
    @GetMapping("/sensorCount")
    public String countSensors(Model model) {
        long count = sensorRepository.count();
        model.addAttribute("sensorCount", count);
        return "sensorCount"; // Will map to sensorCount.html in templates
    }

    // Test route
    @GetMapping("/test")
    @ResponseBody
    public String testRoute() {
        return "test test test";  // Return plain text
    }
}
