package com.allen.midtermtest.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "Sensor")  // This explicitly sets the table name to "Sensor"
public class Sensor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long sensorID;

    @NotBlank(message = "Sensor name is required")
    private String sensorName;

    @NotBlank(message = "Sensor type is required")
    private String sensorType;

    @NotNull(message = "Sensor pin is required")
    @Min(value = 0, message = "Sensor pin must be greater than or equal to 0")
    @Max(value = 1000, message = "Sensor pin must be less than or equal to 1000")
    private Integer sensorPin;

    private String sensorLocation;  // Optional field

    @NotBlank(message = "Sensor status is required")
    private String sensorStatus;  // ON or OFF

    // Getters and Setters

    public Long getSensorID() {
        return sensorID;
    }

    public void setSensorID(Long sensorID) {
        this.sensorID = sensorID;
    }

    public String getSensorName() {
        return sensorName;
    }

    public void setSensorName(String sensorName) {
        this.sensorName = sensorName;
    }

    public String getSensorType() {
        return sensorType;
    }

    public void setSensorType(String sensorType) {
        this.sensorType = sensorType;
    }

    public Integer getSensorPin() {
        return sensorPin;
    }

    public void setSensorPin(Integer sensorPin) {
        this.sensorPin = sensorPin;
    }

    public String getSensorLocation() {
        return sensorLocation;
    }

    public void setSensorLocation(String sensorLocation) {
        this.sensorLocation = sensorLocation;
    }

    public String getSensorStatus() {
        return sensorStatus;
    }

    public void setSensorStatus(String sensorStatus) {
        this.sensorStatus = sensorStatus;
    }
}
