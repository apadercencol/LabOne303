package com.allen.midtermtest.repository;

import com.allen.midtermtest.model.Sensor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SensorRepository extends JpaRepository<Sensor, Long> {
}
